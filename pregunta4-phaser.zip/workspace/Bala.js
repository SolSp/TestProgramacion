Bala=function(game,x,y)
{
    Phaser.Sprite.call(this,game,x,y,'bullet');
	game.physics.arcade.enable(this);				
};

Bala.prototype = Object.create(Phaser.Sprite.prototype);

Bala.prototype.constructor = Bala;

Bala.prototype.update=function()
{
    if(this.y<0)
    	this.kill();
}

